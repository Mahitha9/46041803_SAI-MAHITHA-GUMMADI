package oct9;

import java.util.Scanner;

public class RE {
	public boolean firstnameValidate(String firstname) {
		boolean b1 = firstname.matches("^[A-Z]{1}[a-z]{2,9}$");
		return b1;
	}
	public boolean lastnameValidate(String lastname) {
		boolean b2 = lastname.matches("^[A-Z]{1}[a-z]{2,9}$");
		return b2;
	}
	public boolean brandValidate(String brand) {
		boolean b3 = brand.matches("^[A-Z]{1}[a-z]{2,9}$");
		return b3;
	}
	public boolean budgetValidate(String budget) {
		boolean b4 = budget.matches("^[1-9]{1}[0-9]{3,9}$");
		return b4;
	}
	public boolean quantityValidate(String quantity) {
		boolean b5 = quantity.matches("^[1-9]{1}[0-9]{2,9}$");
		return b5;
	}

	public static void main(String args[]) {
		Scanner sc1=new Scanner(System.in);
		String firstname=sc1.next();
		Scanner sc2=new Scanner(System.in);
		String lastname=sc2.next();
		Scanner sc3=new Scanner(System.in);
		String brand=sc3.next();
		Scanner sc4=new Scanner(System.in);
		String budget=sc4.next();
		Scanner sc5=new Scanner(System.in);
		String quantity=sc1.next();
		RE re= new RE();
		boolean b1=re.firstnameValidate(firstname);
		boolean b2=re.lastnameValidate(lastname);
		boolean b3=re.brandValidate(brand);
		boolean b4=re.budgetValidate(budget);
		boolean b5=re.quantityValidate(quantity);
		
		if(b1) {
			System.out.println("Validated first name");
		}else {
			System.out.println("first name not validated");
		}
		if(b2) {
			System.out.println("Validated last name");
		}else {
			System.out.println("last name not validated");
		}
		if(b3) {
			System.out.println("Validated brand");
		}else {
			System.out.println("brand not validated");
		}
		if(b4) {
			System.out.println("Validated budget");
		}else {
			System.out.println("budget not validated");
		}
		if(b5) {
			System.out.println("Validated quantiy");
		}else {
			System.out.println("quantity not validated");
		}
		
		
		
	}
}
