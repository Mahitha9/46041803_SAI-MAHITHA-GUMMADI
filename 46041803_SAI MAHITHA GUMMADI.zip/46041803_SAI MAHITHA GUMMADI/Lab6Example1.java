package labs;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class Lab6Example1 {

	public static void main(String[] args) {
		Map<Integer, Character> map=new TreeMap<Integer,Character>();
		map.put(1,'a');
		map.put(9,'b');
		map.put(3,'c');
		map.put(4,'d');
		Set<Entry<Integer, Character>> set=map.entrySet();
		Iterator<Entry<Integer, Character>> iterator=set.iterator();
		while(iterator.hasNext()) {
			Map.Entry m=(Map.Entry)iterator.next();
			System.out.println(m.getKey()+" "+m.getValue());
			
		}
	}
}