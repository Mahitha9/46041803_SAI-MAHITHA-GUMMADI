package oct9;

public class NewFile 
{
   private String Bookdetails;
   
   public NewFile(String Bookdetails)
   {
	 this.Bookdetails=Bookdetails;   
   }

   public String getBookdetails()
   {
	return Bookdetails;
   }

   public void setBookdetails(String Bookdetails)
   {
	this.Bookdetails= Bookdetails;
   }
   
   public boolean equals(Object o)
   {
	   System.out.println("From Map");
	   if(o!=null && o instanceof NewFile)
	   {
		   String employeeId=((NewFile)o).getBookdetails();
		   if(employeeId!=null && employeeId.equals(this.getBookdetails()))
		   {
			   return true;
		   }
	   }
	return false;
   }
   
   public int hashCode()
   {
	   System.out.println("From Map...");
	   return this.Bookdetails.hashCode();
   }
}