package labs;

public class Lab3Demo4 {

	public static void main(String[] args) {
		int num=952,sum=0;
		int h=num%10;
		while(num!=0)
		{
			int a=num%10;
			sum=sum*10+a;
			num=num/10;
			
		}
		System.out.println(sum);
	
		
		
		while(sum!=0)
		{
			int k=sum%10;
			sum=sum/10;
			int l=sum%10;
			
			int result=k-l;
			System.out.print(result);
		}
		//System.out.print(h);
	}


}
