package oct9;

import java.util.HashMap;
import java.util.Map;

public class Book
{
  public static void main(String[] args)
  {
	  NewFile c1=new NewFile ("classmate");
	  NewFile c2=new NewFile("classmate");
	  System.out.println(c1.equals(c2));
	  
	  Map<NewFile,BookPrice> Bookdetails=new HashMap<NewFile,BookPrice>();
    
	  Bookdetails.put(c2, new BookPrice());
	  Bookdetails.put(c2, new BookPrice());
	  
	  System.out.println(Bookdetails.size());
	  
	  
  }
}