package oct9;

public class BookPrice 
{
  private int Prices;
  
  public int getPrices() {
	return Prices;
}

public void setPrices(int Prices) {
	this.Prices = Prices;
}

public BookPrice()
  {
	  this.Prices=(int)((Math.random()*101)+1);
  }
}