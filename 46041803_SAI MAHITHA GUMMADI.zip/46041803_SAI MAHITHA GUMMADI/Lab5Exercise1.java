package Lab5;
public class Lab5Exercise1 {
public static void main(String args[]) {
Lab5Exercise1 le1 = new Lab5Exercise1();
try {
System.out.println(le1.validateAge(16));
System.out.println(le1.validateAge(12));
}
catch(InvalidAgeException e) {
System.out.println(e);
}
}
public int validateAge(int age) throws InvalidAgeException {
if(age<=15) {
throw new InvalidAgeException("Age should be greater then 15");
}
else
System.out.println("Age is valid");
return age;
}
}

